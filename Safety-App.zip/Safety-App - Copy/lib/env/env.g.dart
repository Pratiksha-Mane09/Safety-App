// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'env.dart';

// **************************************************************************
// EnviedGenerator
// **************************************************************************

// coverage:ignore-file
// ignore_for_file: type=lint
final class _Env {
  static const List<int> _enviedkeygoogleMapsAPI = <int>[];

  static const List<int> _envieddatagoogleMapsAPI = <int>[];

  static final String googleMapsAPI = String.fromCharCodes(List<int>.generate(
    _envieddatagoogleMapsAPI.length,
    (int i) => i,
    growable: false,
  ).map((int i) => _envieddatagoogleMapsAPI[i] ^ _enviedkeygoogleMapsAPI[i]));
}
